# Ansible Local Collection Example

TODO.
